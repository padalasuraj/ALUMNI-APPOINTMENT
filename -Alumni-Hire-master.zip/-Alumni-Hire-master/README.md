# -Alumni-Hire
Our website contains a database of students studying in a college.The alumni startups and alumni  of the respective college will have the access to the website.The college management will update the students details regularly.
